/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMdiArea>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *power_on;
    QAction *power_off;
    QAction *second_mark_on;
    QAction *second_mark_off;
    QAction *set_no;
    QAction *set_to;
    QAction *set_loc;
    QAction *set_auto_exp;
    QAction *set_shtmi1;
    QAction *set_shtmi2;
    QAction *set_mshior;
    QAction *set_dtmi;
    QAction *set_smti;
    QAction *set_vmti;
    QAction *set_synchro;
    QAction *set_skor;
    QAction *window_state;
    QAction *window_settings;
    QAction *window_info_dev;
    QAction *window_auto_trial;
    QAction *window_mshior;
    QAction *state_on;
    QAction *state_off;
    QAction *start_cyclegram;
    QAction *command_no;
    QAction *command_to;
    QAction *command_loc;
    QAction *command_otclp;
    QWidget *centralwidget;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton_mshior;
    QPushButton *pushButton_dtmi;
    QPushButton *pushButton_shtmi1;
    QPushButton *pushButton_shtmi2;
    QPushButton *pushButton_smti;
    QPushButton *pushButton_vmti;
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *verticalLayout_2;
    QLineEdit *lineEdit_in;
    QLabel *label;
    QTextBrowser *textBrowser;
    QWidget *verticalLayoutWidget_3;
    QVBoxLayout *verticalLayout_3;
    QPushButton *pushButton_dtmiLoc;
    QPushButton *pushButton_mshior_start;
    QPushButton *pushButton_stop;
    QWidget *verticalLayoutWidget_5;
    QVBoxLayout *verticalLayout_5;
    QPushButton *pushButton_snh;
    QPushButton *pushButton_skor;
    QPushButton *pushButton_no;
    QPushButton *pushButton_loc;
    QWidget *verticalLayoutWidget_4;
    QVBoxLayout *verticalLayout_4;
    QPushButton *pushButton_on_power;
    QPushButton *pushButton_off_power;
    QListWidget *listWidget;
    QPushButton *pushButton_tg;
    QMdiArea *mdiArea;
    QMenuBar *menubar;
    QMenu *menu;
    QMenu *menu_2;
    QMenu *menu_7;
    QMenu *menu_8;
    QMenu *menu_4;
    QMenu *menu_5;
    QMenu *menu_6;
    QMenu *menu_3;
    QMenu *menu_9;
    QMenu *menu_10;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1296, 918);
        power_on = new QAction(MainWindow);
        power_on->setObjectName(QString::fromUtf8("power_on"));
        power_off = new QAction(MainWindow);
        power_off->setObjectName(QString::fromUtf8("power_off"));
        second_mark_on = new QAction(MainWindow);
        second_mark_on->setObjectName(QString::fromUtf8("second_mark_on"));
        second_mark_off = new QAction(MainWindow);
        second_mark_off->setObjectName(QString::fromUtf8("second_mark_off"));
        set_no = new QAction(MainWindow);
        set_no->setObjectName(QString::fromUtf8("set_no"));
        set_to = new QAction(MainWindow);
        set_to->setObjectName(QString::fromUtf8("set_to"));
        set_loc = new QAction(MainWindow);
        set_loc->setObjectName(QString::fromUtf8("set_loc"));
        set_auto_exp = new QAction(MainWindow);
        set_auto_exp->setObjectName(QString::fromUtf8("set_auto_exp"));
        set_shtmi1 = new QAction(MainWindow);
        set_shtmi1->setObjectName(QString::fromUtf8("set_shtmi1"));
        set_shtmi2 = new QAction(MainWindow);
        set_shtmi2->setObjectName(QString::fromUtf8("set_shtmi2"));
        set_mshior = new QAction(MainWindow);
        set_mshior->setObjectName(QString::fromUtf8("set_mshior"));
        set_dtmi = new QAction(MainWindow);
        set_dtmi->setObjectName(QString::fromUtf8("set_dtmi"));
        set_smti = new QAction(MainWindow);
        set_smti->setObjectName(QString::fromUtf8("set_smti"));
        set_vmti = new QAction(MainWindow);
        set_vmti->setObjectName(QString::fromUtf8("set_vmti"));
        set_synchro = new QAction(MainWindow);
        set_synchro->setObjectName(QString::fromUtf8("set_synchro"));
        set_skor = new QAction(MainWindow);
        set_skor->setObjectName(QString::fromUtf8("set_skor"));
        window_state = new QAction(MainWindow);
        window_state->setObjectName(QString::fromUtf8("window_state"));
        window_settings = new QAction(MainWindow);
        window_settings->setObjectName(QString::fromUtf8("window_settings"));
        window_info_dev = new QAction(MainWindow);
        window_info_dev->setObjectName(QString::fromUtf8("window_info_dev"));
        window_auto_trial = new QAction(MainWindow);
        window_auto_trial->setObjectName(QString::fromUtf8("window_auto_trial"));
        window_mshior = new QAction(MainWindow);
        window_mshior->setObjectName(QString::fromUtf8("window_mshior"));
        state_on = new QAction(MainWindow);
        state_on->setObjectName(QString::fromUtf8("state_on"));
        state_off = new QAction(MainWindow);
        state_off->setObjectName(QString::fromUtf8("state_off"));
        start_cyclegram = new QAction(MainWindow);
        start_cyclegram->setObjectName(QString::fromUtf8("start_cyclegram"));
        command_no = new QAction(MainWindow);
        command_no->setObjectName(QString::fromUtf8("command_no"));
        command_to = new QAction(MainWindow);
        command_to->setObjectName(QString::fromUtf8("command_to"));
        command_loc = new QAction(MainWindow);
        command_loc->setObjectName(QString::fromUtf8("command_loc"));
        command_otclp = new QAction(MainWindow);
        command_otclp->setObjectName(QString::fromUtf8("command_otclp"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        verticalLayoutWidget = new QWidget(centralwidget);
        verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(430, 0, 121, 228));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton_mshior = new QPushButton(verticalLayoutWidget);
        pushButton_mshior->setObjectName(QString::fromUtf8("pushButton_mshior"));

        verticalLayout->addWidget(pushButton_mshior);

        pushButton_dtmi = new QPushButton(verticalLayoutWidget);
        pushButton_dtmi->setObjectName(QString::fromUtf8("pushButton_dtmi"));

        verticalLayout->addWidget(pushButton_dtmi);

        pushButton_shtmi1 = new QPushButton(verticalLayoutWidget);
        pushButton_shtmi1->setObjectName(QString::fromUtf8("pushButton_shtmi1"));

        verticalLayout->addWidget(pushButton_shtmi1);

        pushButton_shtmi2 = new QPushButton(verticalLayoutWidget);
        pushButton_shtmi2->setObjectName(QString::fromUtf8("pushButton_shtmi2"));

        verticalLayout->addWidget(pushButton_shtmi2);

        pushButton_smti = new QPushButton(verticalLayoutWidget);
        pushButton_smti->setObjectName(QString::fromUtf8("pushButton_smti"));

        verticalLayout->addWidget(pushButton_smti);

        pushButton_vmti = new QPushButton(verticalLayoutWidget);
        pushButton_vmti->setObjectName(QString::fromUtf8("pushButton_vmti"));

        verticalLayout->addWidget(pushButton_vmti);

        verticalLayoutWidget_2 = new QWidget(centralwidget);
        verticalLayoutWidget_2->setObjectName(QString::fromUtf8("verticalLayoutWidget_2"));
        verticalLayoutWidget_2->setGeometry(QRect(560, 0, 172, 94));
        verticalLayout_2 = new QVBoxLayout(verticalLayoutWidget_2);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        lineEdit_in = new QLineEdit(verticalLayoutWidget_2);
        lineEdit_in->setObjectName(QString::fromUtf8("lineEdit_in"));

        verticalLayout_2->addWidget(lineEdit_in);

        label = new QLabel(verticalLayoutWidget_2);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout_2->addWidget(label);

        textBrowser = new QTextBrowser(centralwidget);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));
        textBrowser->setGeometry(QRect(430, 250, 741, 591));
        QFont font;
        font.setFamily(QString::fromUtf8("Droid Sans [MONO]"));
        textBrowser->setFont(font);
        verticalLayoutWidget_3 = new QWidget(centralwidget);
        verticalLayoutWidget_3->setObjectName(QString::fromUtf8("verticalLayoutWidget_3"));
        verticalLayoutWidget_3->setGeometry(QRect(740, 0, 160, 83));
        verticalLayout_3 = new QVBoxLayout(verticalLayoutWidget_3);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        pushButton_dtmiLoc = new QPushButton(verticalLayoutWidget_3);
        pushButton_dtmiLoc->setObjectName(QString::fromUtf8("pushButton_dtmiLoc"));

        verticalLayout_3->addWidget(pushButton_dtmiLoc);

        pushButton_mshior_start = new QPushButton(verticalLayoutWidget_3);
        pushButton_mshior_start->setObjectName(QString::fromUtf8("pushButton_mshior_start"));

        verticalLayout_3->addWidget(pushButton_mshior_start);

        pushButton_stop = new QPushButton(verticalLayoutWidget_3);
        pushButton_stop->setObjectName(QString::fromUtf8("pushButton_stop"));

        verticalLayout_3->addWidget(pushButton_stop);

        verticalLayoutWidget_5 = new QWidget(centralwidget);
        verticalLayoutWidget_5->setObjectName(QString::fromUtf8("verticalLayoutWidget_5"));
        verticalLayoutWidget_5->setGeometry(QRect(560, 100, 160, 141));
        verticalLayout_5 = new QVBoxLayout(verticalLayoutWidget_5);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        pushButton_snh = new QPushButton(verticalLayoutWidget_5);
        pushButton_snh->setObjectName(QString::fromUtf8("pushButton_snh"));

        verticalLayout_5->addWidget(pushButton_snh);

        pushButton_skor = new QPushButton(verticalLayoutWidget_5);
        pushButton_skor->setObjectName(QString::fromUtf8("pushButton_skor"));

        verticalLayout_5->addWidget(pushButton_skor);

        pushButton_no = new QPushButton(verticalLayoutWidget_5);
        pushButton_no->setObjectName(QString::fromUtf8("pushButton_no"));

        verticalLayout_5->addWidget(pushButton_no);

        pushButton_loc = new QPushButton(verticalLayoutWidget_5);
        pushButton_loc->setObjectName(QString::fromUtf8("pushButton_loc"));

        verticalLayout_5->addWidget(pushButton_loc);

        verticalLayoutWidget_4 = new QWidget(centralwidget);
        verticalLayoutWidget_4->setObjectName(QString::fromUtf8("verticalLayoutWidget_4"));
        verticalLayoutWidget_4->setGeometry(QRect(910, 0, 160, 191));
        verticalLayout_4 = new QVBoxLayout(verticalLayoutWidget_4);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        pushButton_on_power = new QPushButton(verticalLayoutWidget_4);
        pushButton_on_power->setObjectName(QString::fromUtf8("pushButton_on_power"));

        verticalLayout_4->addWidget(pushButton_on_power);

        pushButton_off_power = new QPushButton(verticalLayoutWidget_4);
        pushButton_off_power->setObjectName(QString::fromUtf8("pushButton_off_power"));

        verticalLayout_4->addWidget(pushButton_off_power);

        listWidget = new QListWidget(verticalLayoutWidget_4);
        new QListWidgetItem(listWidget);
        new QListWidgetItem(listWidget);
        new QListWidgetItem(listWidget);
        new QListWidgetItem(listWidget);
        new QListWidgetItem(listWidget);
        new QListWidgetItem(listWidget);
        listWidget->setObjectName(QString::fromUtf8("listWidget"));

        verticalLayout_4->addWidget(listWidget);

        pushButton_tg = new QPushButton(verticalLayoutWidget_4);
        pushButton_tg->setObjectName(QString::fromUtf8("pushButton_tg"));

        verticalLayout_4->addWidget(pushButton_tg);

        mdiArea = new QMdiArea(centralwidget);
        mdiArea->setObjectName(QString::fromUtf8("mdiArea"));
        mdiArea->setGeometry(QRect(10, 10, 341, 361));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1296, 20));
        menu = new QMenu(menubar);
        menu->setObjectName(QString::fromUtf8("menu"));
        menu_2 = new QMenu(menubar);
        menu_2->setObjectName(QString::fromUtf8("menu_2"));
        menu_7 = new QMenu(menu_2);
        menu_7->setObjectName(QString::fromUtf8("menu_7"));
        menu_8 = new QMenu(menu_2);
        menu_8->setObjectName(QString::fromUtf8("menu_8"));
        menu_4 = new QMenu(menubar);
        menu_4->setObjectName(QString::fromUtf8("menu_4"));
        menu_5 = new QMenu(menubar);
        menu_5->setObjectName(QString::fromUtf8("menu_5"));
        menu_6 = new QMenu(menubar);
        menu_6->setObjectName(QString::fromUtf8("menu_6"));
        menu_3 = new QMenu(menubar);
        menu_3->setObjectName(QString::fromUtf8("menu_3"));
        menu_9 = new QMenu(menubar);
        menu_9->setObjectName(QString::fromUtf8("menu_9"));
        menu_10 = new QMenu(menubar);
        menu_10->setObjectName(QString::fromUtf8("menu_10"));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        menubar->addAction(menu->menuAction());
        menubar->addAction(menu_2->menuAction());
        menubar->addAction(menu_9->menuAction());
        menubar->addAction(menu_4->menuAction());
        menubar->addAction(menu_3->menuAction());
        menubar->addAction(menu_5->menuAction());
        menubar->addAction(menu_6->menuAction());
        menubar->addAction(menu_10->menuAction());
        menu_2->addAction(menu_7->menuAction());
        menu_2->addAction(menu_8->menuAction());
        menu_7->addAction(power_on);
        menu_7->addAction(power_off);
        menu_8->addAction(second_mark_on);
        menu_8->addAction(second_mark_off);
        menu_4->addAction(set_no);
        menu_4->addAction(set_to);
        menu_4->addAction(set_loc);
        menu_5->addAction(set_auto_exp);
        menu_6->addAction(set_shtmi1);
        menu_6->addAction(set_shtmi2);
        menu_6->addAction(set_mshior);
        menu_6->addAction(set_dtmi);
        menu_6->addAction(set_smti);
        menu_6->addAction(set_vmti);
        menu_6->addSeparator();
        menu_6->addAction(set_synchro);
        menu_6->addAction(set_skor);
        menu_6->addAction(command_no);
        menu_6->addAction(command_to);
        menu_6->addAction(command_loc);
        menu_6->addAction(command_otclp);
        menu_3->addAction(start_cyclegram);
        menu_9->addAction(state_on);
        menu_9->addAction(state_off);
        menu_10->addAction(window_state);
        menu_10->addAction(window_settings);
        menu_10->addAction(window_info_dev);
        menu_10->addAction(window_auto_trial);
        menu_10->addAction(window_mshior);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        power_on->setText(QCoreApplication::translate("MainWindow", "\320\222\320\272\320\273\321\216\321\207\320\270\321\202\321\214", nullptr));
        power_off->setText(QCoreApplication::translate("MainWindow", "\320\236\321\202\320\272\320\273\321\216\321\207\320\270\321\202\321\214", nullptr));
        second_mark_on->setText(QCoreApplication::translate("MainWindow", "\320\222\320\272\320\273\321\216\321\207\320\270\321\202\321\214", nullptr));
        second_mark_off->setText(QCoreApplication::translate("MainWindow", "\320\222\321\213\320\272\320\273\321\216\321\207\320\270\321\202\321\214", nullptr));
        set_no->setText(QCoreApplication::translate("MainWindow", "\320\235\320\260\321\207\320\260\320\273\321\214\320\275\320\260\321\217 \320\276\321\200\320\270\320\265\320\275\321\202\320\260\321\206\320\270\321\217 (\320\235\320\236)", nullptr));
        set_to->setText(QCoreApplication::translate("MainWindow", "\320\242\320\265\320\272\321\203\321\211\320\260\321\217 \320\276\321\200\320\270\320\265\320\275\321\202\320\260\321\206\320\270\321\217 (\320\242\320\236)", nullptr));
        set_loc->setText(QCoreApplication::translate("MainWindow", "\320\233\320\276\320\272\320\260\320\273\320\270\320\267\320\260\321\206\320\270\321\217 (\320\233\320\236\320\232)", nullptr));
        set_auto_exp->setText(QCoreApplication::translate("MainWindow", "\320\220\320\262\321\202\320\276\320\275\320\276\320\274\320\275\321\213\320\265 \320\270\321\201\320\277\321\213\321\202\320\260\320\275\320\270\321\217", nullptr));
        set_shtmi1->setText(QCoreApplication::translate("MainWindow", "\320\250\320\242\320\234\320\2301", nullptr));
        set_shtmi2->setText(QCoreApplication::translate("MainWindow", "\320\250\320\242\320\234\320\2302", nullptr));
        set_mshior->setText(QCoreApplication::translate("MainWindow", "\320\234\320\250\320\230 \320\236\320\240", nullptr));
        set_dtmi->setText(QCoreApplication::translate("MainWindow", "\320\224\320\242\320\234\320\230", nullptr));
        set_smti->setText(QCoreApplication::translate("MainWindow", "\320\241\320\234\320\242\320\230", nullptr));
        set_vmti->setText(QCoreApplication::translate("MainWindow", "\320\222\320\234\320\242\320\230", nullptr));
        set_synchro->setText(QCoreApplication::translate("MainWindow", "\320\232\320\276\320\274\320\260\320\275\320\264\320\260 \320\241\320\230\320\235\320\245\320\240\320\236", nullptr));
        set_skor->setText(QCoreApplication::translate("MainWindow", "\320\232\320\276\320\274\320\260\320\275\320\264\320\260 \320\241\320\232\320\236\320\240", nullptr));
        window_state->setText(QCoreApplication::translate("MainWindow", "1 \320\236\320\272\320\275\320\276 \321\201\320\276\321\201\321\202\320\276\321\217\320\275\320\270\321\217", nullptr));
        window_settings->setText(QCoreApplication::translate("MainWindow", "2 \320\236\320\272\320\275\320\276 \320\277\320\260\321\200\320\260\320\274\320\265\321\202\321\200\320\276\320\262", nullptr));
        window_info_dev->setText(QCoreApplication::translate("MainWindow", "3 \320\241\320\270\321\201\321\202\320\265\320\274\320\275\320\260\321\217 \320\270\320\275\321\204\320\276\321\200\320\274\320\260\321\206\320\270\321\217 \320\277\321\200\320\270\320\261\320\276\321\200\320\276\320\262", nullptr));
        window_auto_trial->setText(QCoreApplication::translate("MainWindow", "4 \320\220\320\262\321\202\320\276\320\275\320\276\320\274\320\275\321\213\320\265 \320\270\321\201\320\277\321\213\321\202\320\260\320\275\320\270\321\217 \320\277\321\200\320\270\320\261\320\276\321\200\320\260", nullptr));
        window_mshior->setText(QCoreApplication::translate("MainWindow", "5 \320\234\320\250\320\230 \320\236\320\240", nullptr));
        state_on->setText(QCoreApplication::translate("MainWindow", "\320\243\321\207\320\260\321\201\321\202\320\276\320\272 \320\262\320\272\320\273\321\216\321\207\320\265\320\275\320\270\321\217", nullptr));
        state_off->setText(QCoreApplication::translate("MainWindow", "\320\243\321\207\320\260\321\201\321\202\320\276\320\272 \320\262\321\213\320\272\320\273\321\216\321\207\320\265\320\275\320\270\321\217", nullptr));
        start_cyclegram->setText(QCoreApplication::translate("MainWindow", "\320\222\321\213\320\277\320\276\320\273\320\275\320\265\320\275\320\270\320\265 \321\202\321\200\320\265\320\261\321\203\320\265\320\274\320\276\320\263\320\276 \321\200\320\265\320\266\320\270\320\274\320\260", nullptr));
        command_no->setText(QCoreApplication::translate("MainWindow", "\320\232\320\276\320\274\320\260\320\275\320\264\320\260 \320\235\320\236", nullptr));
        command_to->setText(QCoreApplication::translate("MainWindow", "\320\232\320\276\320\274\320\260\320\275\320\264\320\276 \320\242\320\236", nullptr));
        command_loc->setText(QCoreApplication::translate("MainWindow", "\320\232\320\276\320\274\320\260\320\275\320\264\320\260 \320\233\320\236\320\232", nullptr));
        command_otclp->setText(QCoreApplication::translate("MainWindow", "\320\232\320\276\320\274\320\260\320\275\320\264\320\260 \320\236\320\242\320\232\320\233 \320\240", nullptr));
        pushButton_mshior->setText(QCoreApplication::translate("MainWindow", "\320\234\320\250\320\230 \320\236\320\240", nullptr));
        pushButton_dtmi->setText(QCoreApplication::translate("MainWindow", "\320\224\320\242\320\234\320\230", nullptr));
        pushButton_shtmi1->setText(QCoreApplication::translate("MainWindow", "\320\250\320\242\320\234\320\2301", nullptr));
        pushButton_shtmi2->setText(QCoreApplication::translate("MainWindow", "\320\250\320\242\320\234\320\2302", nullptr));
        pushButton_smti->setText(QCoreApplication::translate("MainWindow", "\320\241\320\234\320\242\320\230", nullptr));
        pushButton_vmti->setText(QCoreApplication::translate("MainWindow", "\320\222\320\234\320\242\320\230", nullptr));
        lineEdit_in->setText(QCoreApplication::translate("MainWindow", "6", nullptr));
        label->setText(QString());
        pushButton_dtmiLoc->setText(QCoreApplication::translate("MainWindow", "\320\243\320\241\320\224 \320\233\320\236\320\232 + \320\224\320\242\320\234\320\230 \320\233\320\236\320\232", nullptr));
        pushButton_mshior_start->setText(QCoreApplication::translate("MainWindow", "\320\234\320\250\320\230\320\236\320\240", nullptr));
        pushButton_stop->setText(QCoreApplication::translate("MainWindow", "\320\236\321\201\321\202\320\260\320\275\320\276\320\262\320\260", nullptr));
        pushButton_snh->setText(QCoreApplication::translate("MainWindow", "\320\241\320\235\320\245", nullptr));
        pushButton_skor->setText(QCoreApplication::translate("MainWindow", "\320\241\320\232\320\236\320\240", nullptr));
        pushButton_no->setText(QCoreApplication::translate("MainWindow", "\320\235\320\236", nullptr));
        pushButton_loc->setText(QCoreApplication::translate("MainWindow", "\320\233\320\236\320\232", nullptr));
        pushButton_on_power->setText(QCoreApplication::translate("MainWindow", "\320\222\320\272\320\273\321\216\321\207\320\270\321\202\321\214 \320\277\320\270\321\202\320\260\320\275\320\270\320\265", nullptr));
        pushButton_off_power->setText(QCoreApplication::translate("MainWindow", "\320\222\321\213\320\272\320\273\321\216\321\207\320\270\321\202\321\214 \320\277\320\270\321\202\320\260\320\275\320\270\320\265", nullptr));

        const bool __sortingEnabled = listWidget->isSortingEnabled();
        listWidget->setSortingEnabled(false);
        QListWidgetItem *___qlistwidgetitem = listWidget->item(0);
        ___qlistwidgetitem->setText(QCoreApplication::translate("MainWindow", "1", nullptr));
        QListWidgetItem *___qlistwidgetitem1 = listWidget->item(1);
        ___qlistwidgetitem1->setText(QCoreApplication::translate("MainWindow", "2", nullptr));
        QListWidgetItem *___qlistwidgetitem2 = listWidget->item(2);
        ___qlistwidgetitem2->setText(QCoreApplication::translate("MainWindow", "3", nullptr));
        QListWidgetItem *___qlistwidgetitem3 = listWidget->item(3);
        ___qlistwidgetitem3->setText(QCoreApplication::translate("MainWindow", "4", nullptr));
        QListWidgetItem *___qlistwidgetitem4 = listWidget->item(4);
        ___qlistwidgetitem4->setText(QCoreApplication::translate("MainWindow", "5", nullptr));
        QListWidgetItem *___qlistwidgetitem5 = listWidget->item(5);
        ___qlistwidgetitem5->setText(QCoreApplication::translate("MainWindow", "6", nullptr));
        listWidget->setSortingEnabled(__sortingEnabled);

        pushButton_tg->setText(QCoreApplication::translate("MainWindow", "\320\222\321\213\320\261\321\200\320\260\321\202\321\214", nullptr));
        menu->setTitle(QCoreApplication::translate("MainWindow", "\320\244\320\260\320\271\320\273", nullptr));
        menu_2->setTitle(QCoreApplication::translate("MainWindow", "\320\221\320\230", nullptr));
        menu_7->setTitle(QCoreApplication::translate("MainWindow", "\320\237\320\270\321\202\320\260\320\275\320\270\320\265", nullptr));
        menu_8->setTitle(QCoreApplication::translate("MainWindow", "\320\223\320\265\320\275\320\265\321\200\320\260\321\206\320\270\321\217 \321\201\320\265\320\272\321\203\320\275\320\264\320\275\320\276\320\271 \320\274\320\265\321\202\320\272\320\270", nullptr));
        menu_4->setTitle(QCoreApplication::translate("MainWindow", "\320\250\321\202\320\260\321\202\320\275\320\260\321\217 \321\200\320\260\320\261\320\276\321\202\320\260", nullptr));
        menu_5->setTitle(QCoreApplication::translate("MainWindow", "\320\230\321\201\320\277\321\213\321\202\320\260\320\275\320\270\320\265", nullptr));
        menu_6->setTitle(QCoreApplication::translate("MainWindow", "\320\232\320\276\320\274\320\260\320\275\320\264\321\213", nullptr));
        menu_3->setTitle(QCoreApplication::translate("MainWindow", "\320\246\320\270\320\272\320\273\320\276\320\263\321\200\320\260\320\274\320\274\321\213", nullptr));
        menu_9->setTitle(QCoreApplication::translate("MainWindow", "\320\237\320\270\321\202\320\260\320\275\320\270\320\265", nullptr));
        menu_10->setTitle(QCoreApplication::translate("MainWindow", "\320\236\320\272\320\275\320\260", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
